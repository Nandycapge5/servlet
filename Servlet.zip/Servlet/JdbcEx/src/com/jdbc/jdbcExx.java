package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbcExx {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	//loading the driver class
	Class.forName("oracle.jdbc.driver.OracleDriver");
	//create the connection
	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg414","training414");
	//statement
	Statement stmt=conn.createStatement();
	ResultSet result=stmt.executeQuery("select * from emp orderBy eid");
	while(result.next())
	{
		System.out.println(result.getInt(1)+""+result.getString(2));
	}
	
	//execute the query
	
	
	/*boolean result=stmt.execute("create table emp(eid number(10),ename varchar2(14))");
	System.out.println("table created"+result);
	*/
	//execute update for insert the data
	
	//int result=stmt.executeUpdate("insert into emp values(3,'menaka')");
//System.out.println("insert the record"+""+result);
	
	//update
	
	//int result=stmt.executeUpdate("update emp set eid=1 where ename='nandy'");
	//System.out.println("update the data"+result);
	
	//delete
	
	
	/*int result=stmt.executeUpdate("delete from emp  where eid=3");
	System.out.println("delete the data"+result);
	
	*/
//close connection
conn.close();

}
}
