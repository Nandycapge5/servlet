package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class GmailEx {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the username");
		String uname = sc.next();
		System.out.println("Enter the password");
		String pass = sc.next();
		// loading the driver class
		Class.forName("oracle.jdbc.driver.OracleDriver");
		// create the connection
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg414","training414");
		// statement
		//Statement stmt = conn.createStatement();
		PreparedStatement stmt=conn.prepareStatement("insert into gmail values(?,?,?,?)");
		//ResultSet result = stmt.executeQuery("select * from gmail");
		/*while (result.next()) {
//			String uname1 = result.getString("username");
//			String pwd = result.getString(2);

			if (result.getString(1).equals(uname) && result.getString(2).equals(pass))

			System.out.println("Login success");
			 else 
				System.out.println("Invalid password and username");*/
		stmt.setString(1, uname);
		stmt.setString(2, pass);
		ResultSet result=stmt.executeQuery();
		if(result.next())
		{
			System.out.println("login Success");
		}
		else
		{
			System.out.println("invalid please try again");
		}
		conn.close();
	}
}
