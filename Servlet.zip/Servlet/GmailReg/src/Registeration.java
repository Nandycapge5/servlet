

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Registeration
 */
public class Registeration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registeration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		PrintWriter out=response.getWriter();
		String name=request.getParameter("Name");
		String username=request.getParameter("uname");
		String password=request.getParameter("pass");
		String gender=request.getParameter("gender");
		String contactNo=request.getParameter("Number");
		
		try {
			ServletContext context=getServletContext();
			String driver=context.getInitParameter("Driver class");
			String url=context.getInitParameter("url");
			String user1=context.getInitParameter("username");
			String pass=context.getInitParameter("password");
			Class.forName(driver);

			// create the connection
			Connection conn = DriverManager.getConnection(url,user1,pass);
								// statement
			PreparedStatement stmt = conn.prepareStatement("insert into gmail values(?,?,?,?,?) ");
			stmt.setString(1, username);
			stmt.setString(2, password);
			stmt.setString(3, name);
			stmt.setString(4, gender);
			stmt.setString(5,contactNo);
			int result = stmt.executeUpdate();
		
		
		//if(username.equals("nandy")&&(password.equals("nan123")))
		 RequestDispatcher rd=request.getRequestDispatcher("login.html");
		rd.include(request, response);
		out.println("record inserted"+result);
			//out.println("Login success");
		//}
//		else
//		{
//			RequestDispatcher rd1=request.getRequestDispatcher("index.html");
//			rd1.include(request, response);
//		}
//			out.println("please enter valid data");
//		}
		conn.close();
	}
		catch(Exception e)
{System.out.println(e);
			}
}
}


