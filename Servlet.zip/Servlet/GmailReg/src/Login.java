
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at:
		// ").append(request.getContextPath());

		String username = request.getParameter("uname");
		String password = request.getParameter("pass");
		PrintWriter out = response.getWriter();

		try {
			
			ServletConfig config=getServletConfig();
               String name1=config.getInitParameter("name");
               System.out.println(name1);
			ServletContext context=getServletContext();
			String driver=context.getInitParameter("Driver class");
			String url=context.getInitParameter("url");
			String user1=context.getInitParameter("username");
			String pass=context.getInitParameter("password");
			Class.forName(driver);
			// create the connection
			Connection conn = DriverManager.getConnection(url,user1,pass);
			// statement
			PreparedStatement stmt = conn.prepareStatement("select * from gmail where username=? and password=?");
			stmt.setString(1, username);
			stmt.setString(2, password);
			ResultSet result = stmt.executeQuery();
			if (result.next())
			// if(username.equals("nandy")&&(password.equals("nan123")))
			{
				RequestDispatcher rd = request.getRequestDispatcher("Home.html");
				rd.forward(request, response);
				out.println("Welcome to home page" + result.getString("name"));
				// out.println("Login success");
			} else {
				RequestDispatcher rd1 = request.getRequestDispatcher("index.html");
				rd1.include(request, response);
				out.println("please enter valid data");

			}

			conn.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
